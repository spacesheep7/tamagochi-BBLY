import SwiftUI

struct ContentView: View {
    @State private var mascota = MascotaVirtual(nombre: "Beily")

    var body: some View {
        ZStack {
            Color.fondoJuego.ignoresSafeArea()

            VStack(spacing: 22) {
                Text("MASCOTA VIRTUAL")
                    .font(.pixel(13))
                    .tracking(2)
                    .foregroundStyle(.white.opacity(0.75))

                PantallaLCD(mascota: mascota)

                controles
                    .frame(height: 96)
            }
            .padding(.horizontal, 26)
            .padding(.top, 54)
            .padding(.bottom, 32)
            .frame(maxWidth: 380)
            .background(carcasa)
            .padding()
        }
        .task { await correrReloj() }
        .sensoryFeedback(.success, trigger: mascota.vecesRevivida)
        .sensoryFeedback(.error, trigger: mascota.estadoActual) { _, nuevoEstado in
            nuevoEstado == .muerto
        }
    }

    // MARK: - Carcasa

    private var carcasa: some View {
        UnevenRoundedRectangle(
            topLeadingRadius: 160,
            bottomLeadingRadius: 120,
            bottomTrailingRadius: 120,
            topTrailingRadius: 160
        )
        .fill(
            LinearGradient(
                colors: [.carcasaClara, .carcasaOscura],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .overlay {
            UnevenRoundedRectangle(
                topLeadingRadius: 160,
                bottomLeadingRadius: 120,
                bottomTrailingRadius: 120,
                topTrailingRadius: 160
            )
            .strokeBorder(.white.opacity(0.3), lineWidth: 3)
        }
        .shadow(color: .black.opacity(0.5), radius: 18, y: 10)
    }

    // MARK: - Controles

    @ViewBuilder
    private var controles: some View {
        if mascota.estadoActual.estaViva {
            HStack(spacing: 12) {
                BotonFisico(titulo: "COMER", icono: "fork.knife", color: .orange) {
                    mascota.alimentar()
                }
                BotonFisico(titulo: "JUGAR", icono: "gamecontroller.fill", color: .purple) {
                    mascota.jugar()
                }
                BotonFisico(titulo: "BAÑAR", icono: "shower.fill", color: .blue) {
                    mascota.banar()
                }
                BotonFisico(titulo: "DORMIR", icono: "moon.fill", color: .indigo) {
                    mascota.dormir()
                }
            }
        } else {
            BotonRevivir {
                withAnimation(.spring(duration: 0.5, bounce: 0.4)) {
                    mascota.revivir()
                }
            }
        }
    }

    // MARK: - Reloj del juego

    private func correrReloj() async {
        while !Task.isCancelled {
            do {
                try await Task.sleep(for: .seconds(ConfiguracionJuego.segundosPorTick))
            } catch {
                break
            }
            mascota.pasarTiempo()
        }
    }
}

#Preview {
    ContentView()
}
