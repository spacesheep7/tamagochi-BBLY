import SwiftUI

// MARK: - Paleta

extension Color {
    static let lcdClaro = Color(red: 0.69, green: 0.80, blue: 0.56)
    static let lcdOscuro = Color(red: 0.13, green: 0.19, blue: 0.11)
    static let carcasaClara = Color(red: 0.98, green: 0.52, blue: 0.62)
    static let carcasaOscura = Color(red: 0.80, green: 0.28, blue: 0.45)
    static let fondoJuego = Color(red: 0.10, green: 0.09, blue: 0.20)
}

// MARK: - Tipografía

extension Font {
    static func pixel(_ tamano: CGFloat, peso: Weight = .bold) -> Font {
        .system(size: tamano, weight: peso, design: .monospaced)
    }
}

// MARK: - Pantalla LCD

struct PantallaLCD: View {
    let mascota: MascotaVirtual

    var body: some View {
        VStack(spacing: 10) {
            encabezado
            estadisticas
            escena
            consola
        }
        .padding(14)
        .background(Color.lcdClaro)
        .overlay { lineasDeEscaneo }
        .clipShape(.rect(cornerRadius: 18))
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .strokeBorder(Color.lcdOscuro.opacity(0.35), lineWidth: 3)
        }
        .foregroundStyle(Color.lcdOscuro)
    }

    private var encabezado: some View {
        HStack {
            Text(mascota.nombre.uppercased())
            Spacer()
            Text("♥ x\(mascota.vecesRevivida)")
        }
        .font(.pixel(14))
    }

    private var estadisticas: some View {
        VStack(spacing: 5) {
            BarraSegmentada(titulo: "HAMBRE", valor: mascota.hambre)
            BarraSegmentada(titulo: "ENERGÍA", valor: mascota.energia)
            BarraSegmentada(titulo: "FELIZ", valor: mascota.felicidad)
            BarraSegmentada(titulo: "HIGIENE", valor: mascota.higiene)
        }
    }

    private var escena: some View {
        ZStack(alignment: .bottom) {
            Color.clear

            Rectangle()
                .fill(Color.lcdOscuro)
                .frame(height: 3)

            personaje
                .padding(.bottom, 6)
        }
        .frame(height: 150)
    }

    @ViewBuilder
    private var personaje: some View {
        if mascota.estadoActual.estaViva {
            Text(mascota.estadoActual.emoji)
                .font(.system(size: 84))
                .grayscale(1)
                .contrast(1.3)
                .blendMode(.multiply)
                .phaseAnimator([0.0, -14.0]) { vista, desplazamiento in
                    vista.offset(y: desplazamiento)
                } animation: { _ in
                    .easeInOut(duration: mascota.estadoActual == .cansado ? 1.2 : 0.5)
                }
        } else {
            VStack(spacing: 4) {
                Text("GAME OVER")
                    .font(.pixel(18))
                    .phaseAnimator([1.0, 0.2]) { vista, opacidad in
                        vista.opacity(opacidad)
                    } animation: { _ in
                        .easeInOut(duration: 0.6)
                    }

                Text(mascota.estadoActual.emoji)
                    .font(.system(size: 70))
                    .grayscale(1)
                    .contrast(1.3)
                    .blendMode(.multiply)
            }
        }
    }

    private var consola: some View {
        Text(mascota.mensajeConsola)
            .font(.pixel(12, peso: .semibold))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .animation(nil, value: mascota.mensajeConsola)
    }

    private var lineasDeEscaneo: some View {
        Canvas { contexto, tamano in
            var y: CGFloat = 0
            while y < tamano.height {
                let linea = Path(CGRect(x: 0, y: y, width: tamano.width, height: 1))
                contexto.fill(linea, with: .color(.black.opacity(0.06)))
                y += 3
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Barra de estadística

struct BarraSegmentada: View {
    let titulo: String
    let valor: Int

    private let totalSegmentos = 10

    private var segmentosLlenos: Int {
        Int((Double(valor) / 100 * Double(totalSegmentos)).rounded(.up))
    }

    var body: some View {
        HStack(spacing: 6) {
            Text(titulo)
                .font(.pixel(11))
                .frame(width: 66, alignment: .leading)

            HStack(spacing: 2) {
                ForEach(0..<totalSegmentos, id: \.self) { indice in
                    Rectangle()
                        .fill(Color.lcdOscuro.opacity(indice < segmentosLlenos ? 1 : 0.15))
                        .frame(height: 9)
                }
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(titulo)
        .accessibilityValue("\(valor) de 100")
    }
}

// MARK: - Botones

struct EstiloBotonFisico: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : 1)
            .brightness(configuration.isPressed ? -0.08 : 0)
            .animation(.easeOut(duration: 0.1), value: configuration.isPressed)
    }
}

struct BotonFisico: View {
    let titulo: String
    let icono: String
    let color: Color
    let accion: () -> Void

    var body: some View {
        Button(action: accion) {
            VStack(spacing: 6) {
                Image(systemName: icono)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 60, height: 60)
                    .background(color.gradient, in: .circle)
                    .overlay {
                        Circle().strokeBorder(.white.opacity(0.35), lineWidth: 2)
                    }
                    .shadow(color: .black.opacity(0.35), radius: 0, x: 0, y: 4)

                Text(titulo)
                    .font(.pixel(10))
                    .foregroundStyle(.white.opacity(0.9))
            }
        }
        .buttonStyle(EstiloBotonFisico())
        .accessibilityLabel(titulo)
    }
}

struct BotonRevivir: View {
    let accion: () -> Void

    var body: some View {
        Button(action: accion) {
            Label("REVIVIR", systemImage: "heart.fill")
                .font(.pixel(20))
                .foregroundStyle(.white)
                .padding(.horizontal, 36)
                .padding(.vertical, 16)
                .background(Color.green.gradient, in: .capsule)
                .overlay {
                    Capsule().strokeBorder(.white.opacity(0.4), lineWidth: 2)
                }
                .shadow(color: .black.opacity(0.35), radius: 0, x: 0, y: 4)
        }
        .buttonStyle(EstiloBotonFisico())
        .phaseAnimator([1.0, 1.06]) { vista, escala in
            vista.scaleEffect(escala)
        } animation: { _ in
            .easeInOut(duration: 0.7)
        }
        .accessibilityLabel("Revivir mascota")
    }
}
