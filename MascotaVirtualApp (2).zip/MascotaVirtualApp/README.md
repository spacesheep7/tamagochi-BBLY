# MascotaVirtualApp

Mascota virtual tipo Tamagotchi hecha con SwiftUI. Pensada para Xcode 27.2 (Swift 6.4), iOS 17 o superior.

## Estructura

- `MascotaVirtualAppApp.swift`: punto de entrada (`@main`).
- `Models/EstadoMascota.swift`: estados y mensajes.
- `Models/MascotaVirtual.swift`: lógica del juego, revivir y paso del tiempo.
- `Views/ContentView.swift`: pantalla principal.
- `Views/ComponentesRetro.swift`: LCD, barras y botones.
- `Assets.xcassets`: color de acento e ícono (falta tu imagen de 1024x1024).

## Cómo abrirlo en Xcode

1. File > New > Project > iOS > App. Nombre: `MascotaVirtualApp`, Interface: SwiftUI, Language: Swift.
2. Borra los archivos que Xcode genera (`MascotaVirtualAppApp.swift`, `ContentView.swift`, `Assets.xcassets`).
3. Arrastra al navegador de Xcode el contenido de esta carpeta, marcando "Copy items if needed" y el target `MascotaVirtualApp`.
4. Ejecuta con Cmd + R.

## Ajustes del juego

Edita `ConfiguracionJuego` en `Models/MascotaVirtual.swift` para cambiar qué tan rápido se desgasta la mascota.
