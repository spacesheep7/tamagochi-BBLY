import Foundation
import Observation

/// Valores que controlan el ritmo del juego. Ajústalos a tu gusto.
enum ConfiguracionJuego {
    static let segundosPorTick = 5

    static let hambrePorTick = 2
    static let energiaPorTick = 1
    static let felicidadPorTick = 1
    static let higienePorTick = 1
}

@MainActor
@Observable
final class MascotaVirtual {
    let nombre: String
    private(set) var estadoActual: EstadoMascota = .iniciacion

    private(set) var hambre = 30
    private(set) var energia = 80
    private(set) var felicidad = 70
    private(set) var higiene = 100
    private(set) var vecesRevivida = 0
    private(set) var mensajeConsola = ""

    init(nombre: String) {
        self.nombre = nombre
        actualizarEstado()
        mensajeConsola = EstadoMascota.iniciacion.mensaje(para: nombre)
    }

    // MARK: - Estado

    private func actualizarEstado() {
        guard estadoActual.estaViva else { return }

        if hambre >= 100 || energia <= 0 || felicidad <= 0 {
            transitarA(.muerto)
        } else if hambre >= 70 {
            transitarA(.hambriento)
        } else if energia <= 25 {
            transitarA(.cansado)
        } else if felicidad <= 30 || higiene <= 20 {
            transitarA(.triste)
        } else if felicidad >= 80 && energia >= 50 {
            transitarA(.jugueton)
        } else {
            transitarA(.neutro)
        }
    }

    private func transitarA(_ nuevoEstado: EstadoMascota) {
        guard estadoActual != nuevoEstado else { return }
        estadoActual = nuevoEstado
        mensajeConsola = nuevoEstado.mensaje(para: nombre)
    }

    private func aplicarCambios(
        deltaHambre: Int = 0,
        deltaEnergia: Int = 0,
        deltaFelicidad: Int = 0,
        deltaHigiene: Int = 0
    ) {
        hambre = limitar(hambre + deltaHambre)
        energia = limitar(energia + deltaEnergia)
        felicidad = limitar(felicidad + deltaFelicidad)
        higiene = limitar(higiene + deltaHigiene)
    }

    private func limitar(_ valor: Int) -> Int {
        min(100, max(0, valor))
    }

    private func verificarViva() -> Bool {
        guard estadoActual.estaViva else {
            mensajeConsola = "❌ No puedes realizar acciones. \(nombre) ya no está con nosotros."
            return false
        }
        return true
    }

    // MARK: - Acciones

    func alimentar() {
        guard verificarViva() else { return }
        mensajeConsola = "Alimentas a \(nombre)..."
        aplicarCambios(deltaHambre: -40, deltaEnergia: 5, deltaHigiene: -10)
        actualizarEstado()
    }

    func jugar() {
        guard verificarViva() else { return }

        if estadoActual == .cansado {
            mensajeConsola = "Cuidado, \(nombre) está demasiado cansada para jugar."
            return
        }

        mensajeConsola = "🎉 Juegas un rato con \(nombre)..."
        aplicarCambios(deltaHambre: 20, deltaEnergia: -25, deltaFelicidad: 35, deltaHigiene: -15)
        actualizarEstado()
    }

    func banar() {
        guard verificarViva() else { return }
        mensajeConsola = "🛁 Bañas a \(nombre)... ¡Quedó impecable!"
        aplicarCambios(deltaEnergia: -10, deltaFelicidad: 10, deltaHigiene: 100)
        actualizarEstado()
    }

    func dormir() {
        guard verificarViva() else { return }
        mensajeConsola = "🌙 \(nombre) se acuesta a descansar..."
        aplicarCambios(deltaHambre: 15, deltaEnergia: 50)
        actualizarEstado()
    }

    func revivir() {
        guard estadoActual == .muerto else { return }

        hambre = 30
        energia = 80
        felicidad = 70
        higiene = 100
        vecesRevivida += 1

        // Se sale de .muerto para que actualizarEstado() vuelva a evaluar.
        estadoActual = .iniciacion
        actualizarEstado()

        // El mensaje se asigna al final para que no lo pise la transición.
        mensajeConsola = "✨ ¡\(nombre) ha vuelto a la vida! Cuídala bien."
    }

    // MARK: - Paso del tiempo

    /// Llamar periódicamente: la mascota se va desgastando sola.
    func pasarTiempo() {
        guard estadoActual.estaViva else { return }
        aplicarCambios(
            deltaHambre: ConfiguracionJuego.hambrePorTick,
            deltaEnergia: -ConfiguracionJuego.energiaPorTick,
            deltaFelicidad: -ConfiguracionJuego.felicidadPorTick,
            deltaHigiene: -ConfiguracionJuego.higienePorTick
        )
        actualizarEstado()
    }
}
