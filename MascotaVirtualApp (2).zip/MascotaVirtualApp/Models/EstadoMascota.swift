import Foundation

enum EstadoMascota: String, CaseIterable, Identifiable, Sendable {
    case iniciacion = "Iniciación"
    case neutro = "Tranquilo"
    case hambriento = "Hambriento"
    case cansado = "Cansado"
    case jugueton = "Juguetón"
    case triste = "Triste"
    case muerto = "Fallecido"

    var id: String { rawValue }

    var estaViva: Bool { self != .muerto }

    var emoji: String {
        switch self {
        case .iniciacion: "🐣"
        case .neutro: "🙂"
        case .hambriento: "🍔"
        case .cansado: "😴"
        case .jugueton: "🎾"
        case .triste: "😢"
        case .muerto: "💀"
        }
    }

    func mensaje(para nombre: String) -> String {
        switch self {
        case .iniciacion: "¡Bienvenido al mundo, \(nombre)! Tu aventura comienza ahora."
        case .neutro: "🙂 \(nombre) está tranquila contemplando el ambiente."
        case .hambriento: "🍔 \(nombre) tiene mucha hambre. Suenan sus tripas."
        case .cansado: "😴 \(nombre) tiene los ojos pesados y necesita dormir, está cansadita."
        case .jugueton: "🎾 \(nombre) está llena de energía y quiere jugar."
        case .triste: "😢 \(nombre) se siente desatendida, le hace falta un bañito."
        case .muerto: "Lamentablemente, \(nombre) ha fallecido... Fin del juego."
        }
    }
}
